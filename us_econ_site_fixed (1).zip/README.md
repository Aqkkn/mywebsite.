# Static site for Anastasiia Shcherbinina

This is a simple 3-page static website (HTML/CSS) suitable for publishing on GitHub Pages.

Files:
- index.html
- resume.html
- econ.html
- threats.html
- styles.css
- script.js
- files/Щербініна_резюме.pdf (copy of uploaded resume)

To publish on GitHub Pages:
1. Create a new repository.
2. Upload all files and the `files/` folder.
3. In repository Settings -> Pages, set source to the `main` branch and `/ (root)` folder.
