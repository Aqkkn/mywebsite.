document.addEventListener('DOMContentLoaded', ()=> {
  // highlight internal anchor links briefly
  document.querySelectorAll('a.inline-link').forEach(a=>{
    a.addEventListener('click', ()=> {
      // noop for static pages
    })
  })
});
